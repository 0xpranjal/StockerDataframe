from setuptools import setup
setup(name="StockerDataframe", 
    version="0.3", 
    description="A tool which can help you with Stock analysis in an efficient way.",
    long_description="Long description about the package",author="Pranjal", packages=['StockerDataframe'],install_requires=[])